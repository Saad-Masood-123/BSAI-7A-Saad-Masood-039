"""
partA_charts.py — Rebuilds all nine published claims and plots all nine honest redesigns.
Course: Data Visualization Lab (Week 3 — Part A)
Author: Abdul Moeez (BSAI-7A-AbdulMoeez-017)
"""

import os
import matplotlib
if os.environ.get("MPLBACKEND") == "Agg":
    matplotlib.use("Agg")
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.size"] = 10

DATA_DIR = "Datasets" if os.path.exists("Datasets") else "data"

def load_data(filename):
    return pd.read_csv(os.path.join(DATA_DIR, filename))

# ==============================================================================
# CASE 1: Helmet Grade & Head Injuries
# ==============================================================================
print("--- Case 1: Helmet Grade Safety ---")
c1_df = load_data("case01_helmet_rickshaw.csv")
c1_agg = c1_df.groupby("helmet_grade").agg(injuries=("head_injuries", "sum"), trips=("trips", "sum")).reset_index()
c1_agg["rate_per_1k"] = (c1_agg["injuries"] / c1_agg["trips"]) * 1000

# Rebuild
fig, ax = plt.subplots(figsize=(6, 4))
ax.bar(c1_agg["helmet_grade"], c1_agg["rate_per_1k"], color=["#3498db", "#e74c3c"], width=0.5)
ax.set_title("BAD EXAMPLE — Premium Helmets Show 2.5x Injury Rate (Self-Check: Standard 2.15, Premium 5.40)", color="red", fontsize=10, fontweight="bold")
ax.set_ylabel("Head Injuries per 1,000 Trips")
ax.set_ylim(0, 7)
for p in ax.patches:
    ax.annotate(f"{p.get_height():.2f}", (p.get_x() + p.get_width()/2., p.get_height() + 0.15), ha='center', fontweight='bold')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# Redesign (Disaggregated by Road Type)
c1_road = c1_df.groupby(["road_type", "helmet_grade"]).agg(injuries=("head_injuries", "sum"), trips=("trips", "sum")).reset_index()
c1_road["rate_per_1k"] = (c1_road["injuries"] / c1_road["trips"]) * 1000

fig, ax = plt.subplots(figsize=(8, 5))
road_types = ["Inner-city lanes", "City arterial", "Motorway"]
x = np.arange(len(road_types))
w = 0.35
std_rates = [c1_road[(c1_road["road_type"]==rt) & (c1_road["helmet_grade"]=="Standard")]["rate_per_1k"].values[0] for rt in road_types]
prm_rates = [c1_road[(c1_road["road_type"]==rt) & (c1_road["helmet_grade"]=="Premium")]["rate_per_1k"].values[0] for rt in road_types]

ax.bar(x - w/2, std_rates, width=w, label="Standard Helmet", color="#2980b9")
ax.bar(x + w/2, prm_rates, width=w, label="Premium Helmet", color="#27ae60")
ax.set_xticks(x)
ax.set_xticklabels(road_types)
ax.set_title("Premium Helmets Have Lower Injury Rates Within Every Road Type (Confounded by High-Risk Trips)", fontsize=11, fontweight="bold")
ax.set_ylabel("Head Injuries per 1,000 Trips")
ax.set_ylim(0, 12)
ax.legend(frameon=True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# ==============================================================================
# CASE 2: Chai Sales vs Quiz Failures
# ==============================================================================
print("--- Case 2: Chai Sales vs Quiz Failures ---")
c2_df = load_data("case02_chai_quizzes.csv")
r2 = c2_df["cups_doodh_patti_sold"].corr(c2_df["quiz_failures"])

# Rebuild
fig, ax = plt.subplots(figsize=(7, 5))
ax.scatter(c2_df["cups_doodh_patti_sold"], c2_df["quiz_failures"], color="#e67e22", s=50)
m, b = np.polyfit(c2_df["cups_doodh_patti_sold"], c2_df["quiz_failures"], 1)
x_line = np.linspace(c2_df["cups_doodh_patti_sold"].min(), c2_df["cups_doodh_patti_sold"].max(), 100)
ax.plot(x_line, m*x_line + b, color="black", linestyle="--", label=f"Pearson r = {r2:.2f}")
ax.set_title(f"BAD EXAMPLE — Chai Sales Predict Quiz Failures (r = {r2:.2f})", color="red", fontsize=10, fontweight="bold")
ax.set_xlabel("Cups of Doodh Patti Sold")
ax.set_ylabel("Quiz Failures Recorded")
ax.legend(frameon=True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# Redesign (Colored by Exam Month)
fig, ax = plt.subplots(figsize=(8, 5))
exam_colors = {0: "#2b5c8f", 1: "#e74c3c"}
for is_exam, group in c2_df.groupby("is_exam_month"):
    lbl = "Exam Month (High Attendance)" if is_exam == 1 else "Regular Teaching Month"
    ax.scatter(group["cups_doodh_patti_sold"], group["quiz_failures"], color=exam_colors[is_exam], s=65, label=lbl, alpha=0.85)

ax.set_title("Spurious Chai-Failure Correlation Disappears When Controlling for Examination Periods", fontsize=11, fontweight="bold")
ax.set_xlabel("Cups of Doodh Patti Sold")
ax.set_ylabel("Quiz Failures Recorded")
ax.legend(frameon=True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# ==============================================================================
# CASE 3: Lahore AQI Monitors
# ==============================================================================
print("--- Case 3: Lahore AQI Monitors ---")
c3_df = load_data("case03_aqi_monitors.csv")
c3_df["date"] = pd.to_datetime(c3_df["date"])
daily_aqi_all = c3_df.groupby("date")["aqi"].mean().reset_index()
daily_aqi_all["day_num"] = (daily_aqi_all["date"] - daily_aqi_all["date"].min()).dt.days + 1

before_m = daily_aqi_all.loc[daily_aqi_all["day_num"] <= 60, "aqi"].mean()
after_m = daily_aqi_all.loc[daily_aqi_all["day_num"] > 60, "aqi"].mean()

# Rebuild
fig, ax = plt.subplots(figsize=(9, 4.5))
ax.plot(daily_aqi_all["day_num"], daily_aqi_all["aqi"], color="#2b5c8f", linewidth=1.5)
ax.axvline(61, color="black", linestyle="--", label="Day 61: Smog Action Plan")
ax.hlines(before_m, 1, 60, colors="#e74c3c", linewidth=2.5, label=f"Days 1-60 Mean ({before_m:.0f})")
ax.hlines(after_m, 61, 120, colors="#27ae60", linewidth=2.5, label=f"Days 61-120 Mean ({after_m:.0f}) [-32%]")
ax.set_title(f"BAD EXAMPLE — Smog Action Plan Cut AQI by 32% (Before: {before_m:.0f}, After: {after_m:.0f})", color="red", fontsize=10, fontweight="bold")
ax.set_xlabel("Day Number (1 to 120)")
ax.set_ylabel("Mean AQI Across Reporting Stations")
ax.set_ylim(0, 300)
ax.legend(frameon=True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# Redesign (Consistently Reporting Stations Only)
reporting_counts = c3_df.dropna(subset=["aqi"]).groupby("station_id")["date"].nunique()
consistent_stations = reporting_counts[reporting_counts == 120].index.tolist()
c3_clean = c3_df[c3_df["station_id"].isin(consistent_stations)]
daily_clean = c3_clean.groupby("date")["aqi"].mean().reset_index()
daily_clean["day_num"] = (daily_clean["date"] - daily_clean["date"].min()).dt.days + 1

c_before = daily_clean.loc[daily_clean["day_num"] <= 60, "aqi"].mean()
c_after = daily_clean.loc[daily_clean["day_num"] > 60, "aqi"].mean()

fig, ax = plt.subplots(figsize=(9, 4.5))
ax.plot(daily_clean["day_num"], daily_clean["aqi"], color="#2b5c8f", linewidth=1.5)
ax.axvline(61, color="black", linestyle="--", label="Day 61: Smog Action Plan")
ax.hlines(c_before, 1, 60, colors="#e74c3c", linewidth=2.5, label=f"Days 1-60 Mean ({c_before:.0f})")
ax.hlines(c_after, 61, 120, colors="#e74c3c", linewidth=2.5, label=f"Days 61-120 Mean ({c_after:.0f}) [Flat]")
ax.set_title("True AQI Remained Flat; Apparent Drop Was Caused by Industrial Stations Going Offline", fontsize=11, fontweight="bold")
ax.set_xlabel("Day Number (1 to 120)")
ax.set_ylabel("Mean AQI (Consistently Reporting Stations, N=10)")
ax.set_ylim(0, 300)
ax.legend(frameon=True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# ==============================================================================
# CASE 4: Quartet Departments (Anscombe's Quartet)
# ==============================================================================
print("--- Case 4: Quartet Departments ---")
c4_df = load_data("case04_quartet_depts.csv")

# Rebuild (Table)
summary_c4 = []
for dept, g in c4_df.groupby("department"):
    summary_c4.append({
        "Department": dept,
        "n": len(g),
        "Mean Hours": round(g["study_hours_per_week"].mean(), 2),
        "Mean Score": round(g["final_score_out_of_20"].mean(), 2),
        "SD Hours": round(g["study_hours_per_week"].std(), 2),
        "SD Score": round(g["final_score_out_of_20"].std(), 2),
        "Pearson r": round(g["study_hours_per_week"].corr(g["final_score_out_of_20"]), 3)
    })
print("BAD EXAMPLE TABLE (Case 4 Summary Stats):")
print(pd.DataFrame(summary_c4).to_string(index=False))

# Redesign (2x2 Scatter Grid)
fig, axes = plt.subplots(2, 2, figsize=(10, 8), sharex=True, sharey=True)
depts = sorted(c4_df["department"].unique())
for ax, dept in zip(axes.flat, depts):
    sub = c4_df[c4_df["department"] == dept]
    ax.scatter(sub["study_hours_per_week"], sub["final_score_out_of_20"], color="#2b5c8f", s=50)
    m, b = np.polyfit(sub["study_hours_per_week"], sub["final_score_out_of_20"], 1)
    x_f = np.linspace(4, 20, 50)
    ax.plot(x_f, m*x_f + b, color="#e74c3c", linestyle="--")
    ax.set_title(dept, fontsize=11, fontweight="bold")
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

fig.suptitle("Anscombe's Quartet in Academic Departments: Identical Summary Stats Conceal 4 Distinct Geometries", fontsize=12, fontweight="bold")
plt.tight_layout()
plt.show()

# ==============================================================================
# CASE 5: Same Stats Shapes (Datasaurus Dozen)
# ==============================================================================
print("--- Case 5: Same Stats Shapes ---")
c5_df = load_data("case05_same_stats_shapes.csv")

# Rebuild (Table)
summary_c5 = []
for shape, g in c5_df.groupby("shape_name"):
    summary_c5.append({
        "Shape Cohort": shape,
        "n": len(g),
        "Mean Hours": round(g["hours_on_platform"].mean(), 2),
        "Mean Score": round(g["assessment_score"].mean(), 2),
        "SD Hours": round(g["hours_on_platform"].std(), 2),
        "SD Score": round(g["assessment_score"].std(), 2),
        "Pearson r": round(g["hours_on_platform"].corr(g["assessment_score"]), 3)
    })
print("BAD EXAMPLE TABLE (Case 5 Summary Stats):")
print(pd.DataFrame(summary_c5).to_string(index=False))

# Redesign (1x5 Scatter Grid)
shapes = sorted(c5_df["shape_name"].unique())
fig, axes = plt.subplots(1, 5, figsize=(16, 3.5), sharex=True, sharey=True)
for ax, s_name in zip(axes, shapes):
    sub = c5_df[c5_df["shape_name"] == s_name]
    ax.scatter(sub["hours_on_platform"], sub["assessment_score"], color="#2b5c8f", s=15, alpha=0.7)
    ax.set_title(s_name.capitalize(), fontsize=10, fontweight="bold")
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

fig.suptitle("Identical Summary Statistics (Mean 48/63, SD 12/15, r=0.42) Conceal Geometric Shapes", fontsize=13, fontweight="bold", y=1.05)
plt.tight_layout()
plt.show()

# ==============================================================================
# CASE 6: Sensor Correlation Matrix
# ==============================================================================
print("--- Case 6: Sensor Matrix ---")
c6_df = load_data("case06_sensor_matrix.csv")
num_c6 = [c for c in c6_df.select_dtypes(include=np.number).columns if c not in ["age_band", "study_site", "hr_device_model"]]
corr_c6 = c6_df[num_c6].corr()

# Rebuild
fig, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(corr_c6, cmap="Reds", annot=True, fmt=".2f", ax=ax, cbar=True)
ax.set_title("BAD EXAMPLE — Correlation Matrix Drawn with Unconstrained Reds Palette and Unassigned Probes", color="red", fontsize=10, fontweight="bold")
plt.tight_layout()
plt.show()

# Redesign (Calibrated Metrics Only, Diverging Palette with vmin=-1, vmax=1)
calibrated_cols = [c for c in num_c6 if not c.startswith("probe_")]
corr_calibrated = c6_df[calibrated_cols].corr()

fig, ax = plt.subplots(figsize=(9, 7))
sns.heatmap(corr_calibrated, cmap="vlag", vmin=-1.0, vmax=1.0, center=0, annot=True, fmt=".2f", ax=ax, cbar=True, square=True)
ax.set_title("Calibrated Clinical Metrics Matrix (Unassigned Raw Probe Channels Removed)", fontsize=11, fontweight="bold")
plt.tight_layout()
plt.show()

# ==============================================================================
# CASE 7: ShaheenGo Dual-Axis Series
# ==============================================================================
print("--- Case 7: ShaheenGo Revenue vs Cost ---")
c7_df = load_data("case07_dual_axis_series.csv")

# Rebuild
fig, ax1 = plt.subplots(figsize=(8, 4.5))
ax2 = ax1.twinx()
ax1.plot(c7_df["month"], c7_df["revenue_pkr_m"], color="#27ae60", marker="o", linewidth=2.5, label="Revenue")
ax2.plot(c7_df["month"], c7_df["cost_pkr_m"], color="#e74c3c", marker="s", linewidth=2.5, label="Cost")
ax1.set_ylim(50, 80)
ax2.set_ylim(40, 56)
ax1.set_ylabel("Revenue (PKR M)", color="#27ae60")
ax2.set_ylabel("Cost (PKR M)", color="#e74c3c")
ax1.set_title("BAD EXAMPLE — Dual-Axis Scale Distortion Makes Revenue Appear Lower Than Cost (Jan–Apr)", color="red", fontsize=10, fontweight="bold")
plt.tight_layout()
plt.show()

# Redesign (Single Axis)
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.plot(c7_df["month"], c7_df["revenue_pkr_m"], color="#27ae60", marker="o", linewidth=2.5, label="Monthly Revenue (PKR M)")
ax.plot(c7_df["month"], c7_df["cost_pkr_m"], color="#e74c3c", marker="s", linewidth=2.5, label="Monthly Cost (PKR M)")
ax.set_title("ShaheenGo Maintained Positive Profitability Throughout All Months (Jan–Jun 2026)", fontsize=11, fontweight="bold")
ax.set_xlabel("Month")
ax.set_ylabel("Amount (PKR Millions)")
ax.set_ylim(0, 90)
ax.legend(frameon=True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# ==============================================================================
# CASE 8: Systolic Bin Widths
# ==============================================================================
print("--- Case 8: Systolic Bin Widths ---")
v_df = load_data("vitals_10k.csv")

# Rebuild (3 panels)
fig, axes = plt.subplots(1, 3, figsize=(13, 4))
bin_settings = [3, 45, 400]
titles = ["bins=3 (Over-smoothed)", "bins=45 (Optimal)", "bins=400 (Under-smoothed/Comb Artifact)"]
for ax, b, t in zip(axes, bin_settings, titles):
    ax.hist(v_df["systolic"], bins=b, color="#2b5c8f", edgecolor="black", alpha=0.7)
    ax.set_title(t, fontsize=10, fontweight="bold")
    ax.set_xlabel("Systolic BP (mmHg)")
    ax.set_ylabel("Count")
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
fig.suptitle("BAD EXAMPLE — Arbitrary Histogram Bin Widths Distort Visual Distribution Shape", color="red", fontsize=11, fontweight="bold")
plt.tight_layout()
plt.show()

# Redesign (Optimal Freedman-Diaconis Bins + KDE)
fig, ax = plt.subplots(figsize=(8, 5))
sns.histplot(v_df["systolic"], bins=35, kde=True, color="#2b5c8f", edgecolor="white", ax=ax, alpha=0.75)
ax.set_title("Systolic Blood Pressure Follows Unimodal Distribution with Digit Preference Peaks at Tens", fontsize=11, fontweight="bold")
ax.set_xlabel("Systolic Blood Pressure (mmHg)")
ax.set_ylabel("Patient Frequency (N = 10,000)")
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# ==============================================================================
# CASE 9: SpO2 Density Leakage
# ==============================================================================
print("--- Case 9: SpO2 Density Leakage ---")

# Rebuild
fig, ax = plt.subplots(figsize=(8, 4.5))
sns.kdeplot(v_df["spo2"], ax=ax, color="#e74c3c", linewidth=2.5)
ax.axvline(100, color="black", linestyle="--", label="100% Physical Ceiling")
ax.set_xlim(85, 108)
ax.set_title("BAD EXAMPLE — Default KDE Kernel Bleeds Density Past 100% Physical Ceiling (4.4% Leakage)", color="red", fontsize=10, fontweight="bold")
ax.set_xlabel("Peripheral Oxygen Saturation (SpO2 %)")
ax.legend(frameon=True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

# Redesign (Bounded KDE cut=0 & Discrete Hist)
fig, ax = plt.subplots(figsize=(8, 4.5))
sns.histplot(v_df["spo2"], discrete=True, color="#2b5c8f", ax=ax, alpha=0.8, stat="probability")
sns.kdeplot(v_df["spo2"], cut=0, clip=(85, 100), color="#e74c3c", linewidth=2, ax=ax, label="Bounded KDE (cut=0)")
ax.axvline(100, color="black", linestyle="--", label="100% Physical Ceiling")
ax.set_title("SpO2 Distribution Strictly Bound at 100% Physical Ceiling (Boundary Cut Applied)", fontsize=11, fontweight="bold")
ax.set_xlabel("Peripheral Oxygen Saturation (SpO2 %)")
ax.set_ylabel("Probability Density")
ax.set_xlim(85, 102)
ax.legend(frameon=True)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
plt.tight_layout()
plt.show()

print("All Part A charts rebuilt and redesigned successfully!")
