# Part A — Diagnosis of Nine Published Claims

**Author:** Abdul Moeez (BSAI-7A-AbdulMoeez-017)  
**Course:** Data Visualization Lab (Week 3 — Part A)  

---

### Case 1 · "Premium-certified helmets have 2.5x the head-injury rate" (`case01_helmet_rickshaw.csv`)
1. **Rebuild & Self-Check:**  
   Standard grade injury rate = **2.15** per 1,000 trips ($129 / 60,000$).  
   Premium grade injury rate = **5.40** per 1,000 trips ($216 / 40,000$).  
   Ratio = $5.40 / 2.15 = 2.51 \times$.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* Premium helmets are unsafe or defective.  
   *Decoy Objection & Rejection:* "Riders wearing Premium helmets drive faster or are less experienced." Data shows mean speed is identical ($38.2$ vs $38.4$ kph) and rider experience is higher for Premium wearers ($24.2$ vs $18.1$ months).
3. **The Mechanism:**  
   **Confounding by Exposure Risk / Simpson's Paradox:** Premium helmets are disproportionately worn on high-risk **Motorways** ($15,000$ trips vs $5,000$) and **City Arterials** ($20,000$ vs $15,000$). Within *every single road type*, Premium helmets have **lower** injury rates (Motorway: Premium $9.60$ vs Standard $12.40$; City arterial: Premium $3.60$ vs Standard $4.40$; Inner-city: Premium $0.60$ vs Standard $0.80$).
4. **The Redesign:**  
   A grouped bar chart disaggregated by `road_type` demonstrating that Premium helmets consistently reduce injury rates within each exposure risk category.

---

### Case 2 · "Canteen chai sales predict quiz failures" (`case02_chai_quizzes.csv`)
1. **Rebuild & Self-Check:**  
   Scatter plot of `cups_doodh_patti_sold` vs `quiz_failures`. Least-squares fit yields **Pearson $r = 0.9820$**.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* Canteen tea consumption causes academic failure.  
   *Decoy Objection & Rejection:* "Correlation is not causation" / "Tea causes sleep loss". This objection names no structural mechanism and ignores the academic calendar.
3. **The Mechanism:**  
   **Confounding by Active Student Volume / Examination Periods (`is_exam_month`):**  
   During exam months (`is_exam_month = 1`), campus open days and student attendance surge. Exam sittings generate high quiz failure volumes *and* high canteen sales simultaneously. In non-exam months, chai sales range $4,000–6,000$ and failures range $10–25$; in exam months, chai sales reach $12,000–16,000$ and failures reach $70–95$. Controlling for exam months causes the correlation to vanish within groups ($r \approx 0.12$).
4. **The Redesign:**  
   Scatter plot with points color-coded by `is_exam_month` (Exam vs Regular Teaching months) exposing the two distinct cluster clouds.

---

### Case 3 · "The Smog Action Plan cut Lahore's AQI by a third" (`case03_aqi_monitors.csv`)
1. **Rebuild & Self-Check:**  
   Mean AQI for days 1–60 = **202.09**. Mean AQI for days 61–120 = **137.21**. **Fall = 32.1%**.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* Government policy intervention cut air pollution by 32%.  
   *Decoy Objection & Rejection:* "Seasonal wind shift or rainfall occurred after day 60." Meteorological records show no weather change.
3. **The Mechanism:**  
   **Survivor Bias / Attrition of Highly Polluted Monitoring Stations:**  
   `pandas.mean()` silently ignores missing `NaN` values. Between days 1–60, heavily polluted Industrial stations (`LHR-01` to `LHR-06`, mean AQI $> 280$) were reporting. After day 60, these industrial stations went **offline** (`station_status = offline`), leaving only clean Peri-urban stations (`LHR-18` to `LHR-22`, mean AQI $< 120$) reporting! Among the $N = 10$ stations that reported consistently across all 120 days, true AQI was **194.8 before vs 194.2 after (0.3% change)**.
4. **The Redesign:**  
   Line chart tracking mean AQI calculated *only* across consistently reporting stations ($N=10$), declaring station exclusion on the figure.

---

### Case 4 · "Four departments behave identically, so fund them equally" (`case04_quartet_depts.csv`)
1. **Rebuild & Self-Check:**  
   All 4 departments report: $n=11$, mean study hours = **18.00**, mean score = **14.50**, SD hours = **3.32**, SD score = **2.03**, Pearson $r = \mathbf{0.816}$, regression line $y = 3.0 + 0.5x$.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* Student study patterns are identical across all departments.  
   *Decoy Objection & Rejection:* "Sample size $n=11$ is too small." Small samples can still reveal structural relationships when plotted.
3. **The Mechanism:**  
   **Anscombe's Quartet Structural Non-Linearity:**  
   - Dept Architecture: True linear relationship.  
   - Dept Business: Non-linear quadratic curve (peaks at 12 hours).  
   - Dept Computer Science: Tight linear relationship ruined by a single vertical outlier ($x=13, y=12.74$).  
   - Dept Electrical Eng: High-leverage outlier ($x=19, y=12.50$) forcing an artificial slope on vertical data ($x=8$).
4. **The Redesign:**  
   A 2x2 grid of scatter plots with regression trendlines revealing the 4 distinct structural distributions.

---

### Case 5 · "Five cohorts, one set of statistics" (`case05_same_stats_shapes.csv`)
1. **Rebuild & Self-Check:**  
   All 5 cohorts report: $n=180$, mean hours = **48.00**, mean score = **63.00**, SD hours = **12.03**, SD score = **15.04**, Pearson $r = \mathbf{0.420}$.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* Learning platform engagement is uniform across all cohorts.  
   *Decoy Objection & Rejection:* "Correlation $r=0.42$ is too weak." Weak correlation does not explain geometric spatial patterns.
3. **The Mechanism:**  
   **Geometric Shape Disguise (The Datasaurus / Matejka & Fitzmaurice):**  
   The data points form distinct geometric shapes: Cohort 1 = **Hollow Ring**, Cohort 2 = **Five-Pointed Star**, Cohort 3 = **Straight Line**, Cohort 4 = **Letter X**, Cohort 5 = **Two Separate Clusters**.
4. **The Redesign:**  
   A 1x5 facet grid of scatter plots displaying the true geometric visual structures of the 5 cohorts.

---

### Case 6 · "Creatinine tracks HbA1c — a finding" (`case06_sensor_matrix.csv`)
1. **Rebuild & Self-Check:**  
   20x20 matrix. Creatinine ↔ HbA1c = **0.77**, Systolic ↔ MAP = **0.96**.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* Kidney function directly tracks blood glucose levels.  
   *Decoy Objection & Rejection:* "Sample size $n=180$ is insufficient." $n=180$ is ample for correlation estimation.
3. **The Mechanism:**  
   - **Drawing Flaw:** `cmap="Reds"` without `vmin`/`vmax` auto-scales the colorbar from $r=0.68$ to $r=0.96$, saturating moderate correlations into dark red.  
   - **Data Flaw (Unassigned Instrument Noise):** `probe_a` ... `probe_f` are raw uncalibrated sensor channels that correlate with each other. Creatinine and HbA1c correlation is driven by shared uncalibrated site noise (`study_site`).
4. **The Redesign:**  
   Annotated heatmap of calibrated clinical metrics only (excluding unassigned probes), using a diverging `vlag` palette with `vmin=-1.0, vmax=1.0, center=0`.

---

### Case 7 · "ShaheenGo ran at a loss until May" (`case07_dual_axis_series.csv`)
1. **Rebuild & Self-Check:**  
   Dual y-axis line chart (`ax.twinx()`). Revenue (50–80) on left, Cost (40–56) on right. Cost line sits visually above Revenue for Jan–Apr.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* The business operated at a loss for 4 months.  
   *Decoy Objection & Rejection:* "Expenses grew too quickly." Expenses were flat ($45\text{M} \to 52\text{M}$).
3. **The Mechanism:**  
   **Dual Y-Axis Scale Manipulation:**  
   Both Revenue and Cost are measured in the **exact same unit (PKR Millions)**. Revenue was ALWAYS higher than Cost (Jan: Revenue 60M vs Cost 45M; Feb: 62M vs 47M). Setting Revenue y-axis 50–80 and Cost y-axis 40–56 visually forced 45M on the right axis higher than 60M on the left axis!
4. **The Redesign:**  
   A single y-axis line plot showing both Revenue and Cost on a shared 0–90 PKR Million scale, proving positive profitability in all 6 months.

---

### Case 8 · "Three bin widths, three different distributions" (`vitals_10k.csv`)
1. **Rebuild & Self-Check:**  
   Side-by-side histograms of `systolic` ($n=10,000$) with `bins=3`, `bins=45`, `bins=400`.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* Patient blood pressure exhibits multimodal population shifts.  
   *Decoy Objection & Rejection:* "Blood pressure readings vary by age group." Age variation does not create artificial comb teeth.
3. **The Mechanism:**  
   **Bin Width Distortion Artifacts:**  
   - `bins=3` severely over-smooths into 3 blocks (hiding features).  
   - `bins=400` severely under-smooths, creating extreme comb-like spikes due to integer rounding in digital BP monitors (digit preference at even numbers).  
   - `bins=35` (Freedman-Diaconis rule) reveals true unimodal distribution.
4. **The Redesign:**  
   Single histogram using mathematically optimal bin width (`bins=35`) with an overlaid KDE curve.

---

### Case 9 · "4.4% of the density sits above 100% saturation" (`vitals_10k.csv`)
1. **Rebuild & Self-Check:**  
   Default KDE of `spo2` extended to 108. Max data value = **100**. 4.4% curve area extends past 100%.
2. **The Conclusion & Decoy:**  
   *Claimed Conclusion:* Data entry error introduced hyper-oxygenated readings $> 100\%$.  
   *Decoy Objection & Rejection:* "Monitors were miscalibrated." `df['spo2'].max()` is strictly $100$.
3. **The Mechanism:**  
   **Unconstrained Kernel Density Boundary Leakage:**  
   Gaussian KDE applies unbounded probability density kernels that bleed past physical boundaries when `cut > 0`. Because $SpO_2$ has a hard physical ceiling at 100%, unconstrained KDE spreads density into non-physical space.
4. **The Redesign:**  
   Histogram with `discrete=True` combined with a bounded KDE (`cut=0, clip=(85, 100)`), declaring the 100% physical ceiling on the chart.
