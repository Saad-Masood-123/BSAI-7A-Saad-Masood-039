"""
partB_lie_factor.py — Lie Factor Calculations and Audit in Python
Course: Data Visualization Lab (Week 3 — Part B)
Author: Abdul Moeez (BSAI-7A-AbdulMoeez-017)
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd
import vizlib

DATA_DIR = "Datasets" if os.path.exists("Datasets") else "data"
lie_df = pd.read_csv(os.path.join(DATA_DIR, "case07_lie_factor.csv"))

results = []
for idx, r in lie_df.iterrows():
    cid = r["chart_id"]
    subj = r["subject"]
    vs, ve = r["value_start"], r["value_end"]
    is_, ie = r["ink_start"], r["ink_end"]
    idim = r["ink_dimension"]
    
    de, ge, lf = vizlib.lie_factor(vs, ve, is_, ie, idim)
    
    if 0.95 <= lf <= 1.05:
        verdict = "Honest (0.95 - 1.05)"
    elif lf > 1.05:
        verdict = f"Exaggerated ({lf:.2f}x)"
    else:
        verdict = f"Understated ({lf:.2f}x)"
        
    results.append({
        "Chart": cid,
        "Subject": subj,
        "Data Start": vs,
        "Data End": ve,
        "Data Effect (%)": f"{de*100:+.1f}%",
        "Ink Start": is_,
        "Ink End": ie,
        "Ink Dim": idim,
        "Graphic Effect (%)": f"{ge*100:+.1f}%",
        "Lie Factor": lf,
        "Verdict": verdict
    })

res_df = pd.DataFrame(results)

print("================================================================================")
print("PART B QUESTION 1: LIE FACTOR AUDIT TABLE (CHARTS A-E)")
print("================================================================================")
print(res_df.to_string(index=False))

print("\n================================================================================")
print("PART B QUESTION 2: HONEST GRAPHIC AND ENCODING FAULTS")
print("================================================================================")
print("• Honest Graphic: CHART C (Export Earnings). Lie Factor = 1.00 (Data Effect +20.0%, Graphic Effect +20.0%).")
print("  Bars strictly originate from zero baseline using 1D length encoding.")
print("\nFaults of the other four graphics:")
print("• Chart A (Corporate Tax): Lie Factor = 75.00 (Exaggerated 75x). Bars drawn from a truncated 29.6% baseline.")
print("• Chart B (Health Budget): Lie Factor = 2.50 (Exaggerated 2.5x). Coin icon scaled 1.5x in BOTH height and width (Area scales 2.25x).")
print("• Chart D (Air Pollution): Lie Factor = 0.25 (Understated 4x). Bars drawn 8cm to 9cm tall (12.5% ink change for 50% data change).")
print("• Chart E (City Population): Lie Factor = 5.00 (Exaggerated 5x). Bubble RADIUS set proportional to value, causing 16x area jump for 4x data jump.")

print("\n================================================================================")
print("PART B QUESTION 3: 2D AREA ENCODINGS & DIMENSION SPECIFICATION")
print("================================================================================")
print("• Graphics requiring ink_dimension=2: Chart B (Coin Icon) and Chart E (Population Bubble).")
print("• What goes wrong if left at 1: If ink_dimension=1 is assumed for 2D area encodings, the code evaluates linear diameter/radius ratio instead of area ratio, under-reporting Chart B's Lie Factor as 1.00 instead of 2.50, and Chart E's Lie Factor as 1.00 instead of 5.00, completely masking the area lie distortion.")

print("\n================================================================================")
print("PART B QUESTION 4: UNDERSTATED DISTORTION (LIE FACTOR < 1.0)")
print("================================================================================")
print("• Understated Distortion: Chart D has a Lie Factor of 0.25 (a 50% pollution increase appears as a tiny 12.5% visual height change).")
print("• Why it is still a distortion: An understated chart deceives the reader by dampening real magnitude, giving a false sense of stability or minimal change.")
print("• Who benefits: Municipal authorities, polluting industrial corporations, or political incumbents seeking to minimize public alarm over worsening air pollution or inflation.")

print("\n================================================================================")
print("PART B QUESTION 5: CHART F DUAL-AXIS LIE FACTOR & DATA TRUTH")
print("================================================================================")
print("• Can Lie Factor be computed for Chart F (Case 7 Dual-Axis Chart)?")
print("  NO. Tufte's Lie Factor formula assumes a SINGLE unified spatial scale where 1 unit of data maps to a fixed unit of graphic ink. A dual-axis chart uses two independent, arbitrary vertical scales (Revenue 50-80 vs Cost 40-56), making the ratio of graphic effect to data effect mathematically undefined and scale-dependent.")
print("• What the data ACTUALLY shows:")
print("  ShaheenGo was NEVER running at a loss. Revenue was strictly greater than Cost in every single month (Jan: 60M vs 45M; Feb: 62M vs 47M; Mar: 65M vs 50M; Apr: 68M vs 52M; May: 72M vs 54M; Jun: 78M vs 55M). The business maintained solid profitability throughout Jan-Jun 2026.")
