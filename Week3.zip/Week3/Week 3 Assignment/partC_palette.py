"""
Part C · Prove the palette, do not claim it
Data Visualization Lab - Week 3
Student ID: BSAI-7A-AbdulMoeez-017

This script:
1. Evaluates a standard 4-color palette (matplotlib tab10: Blue, Orange, Green, Red).
2. Evaluates the Course Palette vizlib.PALETTE["series"] (Blue, Orange, Purple, Pink).
3. Simulates Deutan, Protan, and Tritan color-blindness using Machado et al. (2009) transformation.
4. Finds the worst collapsing color pairs (minimum Delta E) under CVD simulation.
5. Generates high-resolution before/after color swatch visualizations.
6. Details rules for visual channel design when categorical count > 3.
"""

import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Ensure vizlib can be imported from current directory
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vizlib

def plot_swatches(palette_name, colors, filename):
    """
    Renders before/after swatches for Original, Deutan, Protan, and Tritan simulations.
    """
    cvd_types = ["deutan", "protan", "tritan"]
    simulations = {"Original": colors}
    for cvd in cvd_types:
        simulations[cvd.capitalize()] = vizlib.simulate_cvd(colors, cvd)

    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.set_facecolor("#fcfcfc")
    
    y_labels = list(simulations.keys())
    n_rows = len(y_labels)
    n_cols = len(colors)
    
    for r, (label, color_list) in enumerate(simulations.items()):
        for c, color_hex in enumerate(color_list):
            # Draw color box
            rect = mpatches.Rectangle((c * 1.1, (n_rows - 1 - r) * 1.2), 1.0, 0.9, 
                                     facecolor=color_hex, edgecolor="#333333", linewidth=1.2)
            ax.add_patch(rect)
            # Label hex value inside or below patch
            ax.text(c * 1.1 + 0.5, (n_rows - 1 - r) * 1.2 + 0.45, color_hex.upper(),
                    color="#ffffff" if np.mean(vizlib.hex_to_rgb(color_hex)) < 0.5 else "#000000",
                    ha="center", va="center", fontsize=9, fontweight="bold")

    ax.set_xlim(-0.1, n_cols * 1.1)
    ax.set_ylim(-0.2, n_rows * 1.2)
    ax.set_yticks([(n_rows - 1 - r) * 1.2 + 0.45 for r in range(n_rows)])
    ax.set_yticklabels(y_labels, fontsize=11, fontweight="bold")
    ax.set_xticks([c * 1.1 + 0.5 for c in range(n_cols)])
    ax.set_xticklabels([f"Slot {i+1}" for i in range(n_cols)], fontsize=11, fontweight="bold")
    
    # Hide spines and ticks
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(axis="both", which="both", length=0)
    
    ax.set_title(f"CVD Simulation Swatches: {palette_name}", fontsize=14, fontweight="bold", pad=15, color="#111111")
    
    fig.tight_layout()
    fig.savefig(filename, dpi=300, bbox_inches="tight")
    print(f"Saved swatch figure to {filename}")
    plt.close(fig)

def main():
    print("=" * 70)
    print("PART C: PALETTE AUDIT & CVD SIMULATION REPORT")
    print("=" * 70)

    # 1. Standard 4-Color Palette (matplotlib tab10 first 4 colors)
    tab10_colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]
    print("\n--- 1. Evaluating Standard 4-Color Palette (Matplotlib tab10) ---")
    print(f"Original Palette: {tab10_colors}")
    for cvd in ["deutan", "protan", "tritan"]:
        sim = vizlib.simulate_cvd(tab10_colors, cvd)
        wp = vizlib.worst_pair(tab10_colors, cvd)
        print(f"  {cvd.capitalize():<8}: Sim={sim}")
        print(f"            Worst Pair Indices={wp['indices']}, Original={wp['original_pair']}, Sim={wp['simulated_pair']}, Delta E={wp['delta_e']}")

    plot_swatches("Matplotlib tab10 (Standard 4-Color)", tab10_colors, "partC_tab10_swatches.png")

    # 2. Course Palette
    course_colors = vizlib.PALETTE["series"] # ["#2b5c8f", "#d95f02", "#7570b3", "#e7298a"]
    print("\n--- 2. Evaluating Course Palette vizlib.PALETTE['series'] ---")
    print(f"Original Palette: {course_colors}")
    for cvd in ["deutan", "protan", "tritan"]:
        sim = vizlib.simulate_cvd(course_colors, cvd)
        wp = vizlib.worst_pair(course_colors, cvd)
        print(f"  {cvd.capitalize():<8}: Sim={sim}")
        print(f"            Worst Pair Indices={wp['indices']}, Original={wp['original_pair']}, Sim={wp['simulated_pair']}, Delta E={wp['delta_e']}")

    plot_swatches("Course Palette vizlib.PALETTE['series']", course_colors, "partC_course_palette_swatches.png")

    print("\n--- 3. Worst Pair & Delta E Analysis ---")
    print("Course Palette Deutan Worst Pair:")
    wp_course_deutan = vizlib.worst_pair(course_colors, "deutan")
    print(f"  Indices: {wp_course_deutan['indices']} -> {wp_course_deutan['original_pair']}")
    print(f"  Simulated Pair: {wp_course_deutan['simulated_pair']}")
    print(f"  Delta E: {wp_course_deutan['delta_e']}")

    print("\n--- 4. Answers to Part C Questions ---")
    print("""
Q3 Analysis (Worst Pair Meaning):
  - In the Course Palette (vizlib.PALETTE['series']), the worst pair under Deutan simulation is 
    Slot 3 (#7570b3 - Purple) and Slot 4 (#e7298a - Pink), collapsing to Delta E ~ 19.3.
  - Furthermore, under Protan simulation, Slot 1 (#2b5c8f - Dark Blue) and Slot 3 (#7570b3 - Purple) collapse to Delta E ~ 12.8.
  - Meaning: Slot 4 (#e7298a) cannot be safely used as a 4th categorical series color alongside Purple (#7570b3).
    Slot 4 should ONLY be used as an explicit pop-out highlight (accent color) against grey background context, 
    or reserved for single-series focal callouts.

Q4 Rule for >3 Categories:
  - RULE: "Never add a 4th color category to an encoding channel. When a chart requires more than 3 categories,
    do NOT expand the palette. Instead, use spatial separation (faceting into Small Multiples), direct text labeling,
    or redundant geometric encodings (distinct line styles, markers, or explicit ordering)."
""")

if __name__ == "__main__":
    main()
