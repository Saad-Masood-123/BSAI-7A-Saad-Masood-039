"""
Part D · Build the clinical review figure
Data Visualization Lab - Week 3
Student ID: BSAI-7A-AbdulMoeez-017

This script:
1. Loads and inspects vitals_10k.csv and ward_los_wide.csv.
2. Identifies and handles four key data quality issues:
   a. Device Faults: heart_rate > 250 bpm removed (n = 29, mean moves from 78.83 to 77.98 bpm).
   b. Sentinel Placeholders: bmi == 999.0 set to NaN (n = 402, mean moves from 66.18 to 27.11 kg/m²).
   c. Dirty Categories: Standardized 12 raw ward text variants into 4 clean categories.
   d. Mixed Date Formats: Parsed heterogeneous admit_date strings into datetime objects.
3. Reshapes wide ward_los_wide.csv data into long format using pandas.melt().
4. Constructs a 2x2 clinical review multi-panel figure adhering to OO Matplotlib API rules:
   - Panel 1: Systolic BP distribution (Hist + KDE, bin width ~3.4 mmHg declared).
   - Panel 2: Length of stay across wards (Seaborn box plot on long data).
   - Panel 3: Systolic vs Diastolic BP scatter plot (r = 0.889, excluding arithmetic map_mmhg).
   - Panel 4: Annotated correlation heatmap of calibrated vital sign measurements.
5. Saves high-resolution figure at 300 DPI as partD_figure.png before display.
"""

import sys
import os
import matplotlib
if os.environ.get("MPLBACKEND") == "Agg":
    matplotlib.use("Agg")
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Ensure vizlib is accessible
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vizlib

def clean_vitals_data(filepath):
    df = pd.read_csv(filepath)
    
    # Initial stats
    n_initial = len(df)
    hr_mean_raw = df['heart_rate'].mean()
    bmi_mean_raw = df['bmi'].mean()
    
    # 1. Date parsing
    df['admit_date_clean'] = pd.to_datetime(df['admit_date'], format='mixed')
    
    # 2. Ward standardization
    ward_mapping = {
        'General Medicine': 'General Medicine',
        'general medicine': 'General Medicine',
        'Gen Medicine': 'General Medicine',
        'CARDIOLOGY': 'Cardiology',
        'cardio': 'Cardiology',
        'Cardiology': 'Cardiology',
        'Day Surgery': 'Day Surgery',
        'Day-Surgery': 'Day Surgery',
        'Intensive Care': 'ICU',
        'ICU': 'ICU',
        ' I.C.U': 'ICU',
        'icu': 'ICU'
    }
    df['ward_clean'] = df['ward'].map(ward_mapping)
    
    # 3. Heart rate device fault handling (heart_rate > 250)
    hr_fault_mask = df['heart_rate'] > 250
    n_hr_faults = hr_fault_mask.sum()
    df_clean_hr = df[~hr_fault_mask].copy()
    hr_mean_clean = df_clean_hr['heart_rate'].mean()
    
    # 4. BMI sentinel code handling (bmi > 100)
    bmi_fault_mask = df_clean_hr['bmi'] > 100
    n_bmi_faults = bmi_fault_mask.sum()
    df_clean = df_clean_hr.copy()
    df_clean.loc[df_clean['bmi'] > 100, 'bmi'] = np.nan
    bmi_mean_clean = df_clean['bmi'].mean()
    
    print(f"Data Cleaning Summary (Initial N = {n_initial}):")
    print(f"  - Heart Rate > 250 bpm device faults removed: n = {n_hr_faults}. Mean HR: {hr_mean_raw:.2f} -> {hr_mean_clean:.2f} bpm")
    print(f"  - BMI > 100 sentinel placeholders (999.0) converted to NaN: n = {n_bmi_faults}. Mean BMI: {bmi_mean_raw:.2f} -> {bmi_mean_clean:.2f} kg/m²")
    print(f"  - Ward categories standardized into 4 canonical groups: {df_clean['ward_clean'].unique().tolist()}")
    print(f"  - Dates parsed successfully: min {df_clean['admit_date_clean'].min().strftime('%Y-%m-%d')} to max {df_clean['admit_date_clean'].max().strftime('%Y-%m-%d')}")
    
    return df_clean

def load_ward_los_data(filepath):
    df_wide = pd.read_csv(filepath)
    # Reshape wide to long data
    df_long = df_wide.melt(var_name='ward', value_name='los_days').dropna()
    # Normalize ward column names
    ward_rename = {
        'Cardiology': 'Cardiology',
        'Day Surgery': 'Day Surgery',
        'General Medicine': 'General Medicine',
        'Icu': 'ICU'
    }
    df_long['ward'] = df_long['ward'].map(ward_rename)
    return df_long

def build_clinical_review_figure(df_vitals, df_los, output_filename="partD_figure.png"):
    fig, axes = plt.subplots(2, 2, figsize=(14, 11))
    fig.subplots_adjust(hspace=0.35, wspace=0.25)
    
    # Global aesthetics
    primary_color = vizlib.PALETTE["primary"]
    accent_color = vizlib.PALETTE["series"][1]
    
    # ----------------------------------------------------
    # Panel 1: Distribution of Systolic Blood Pressure
    # ----------------------------------------------------
    ax1 = axes[0, 0]
    sns.histplot(df_vitals['systolic'], bins=35, kde=True, ax=ax1, color=primary_color, edgecolor="#ffffff", linewidth=0.6)
    ax1.axvline(120, color="#27ae60", linestyle="--", linewidth=1.5, label="Normal Threshold (120 mmHg)")
    ax1.axvline(140, color="#e74c3c", linestyle="--", linewidth=1.5, label="Hypertension Threshold (140 mmHg)")
    
    ax1.set_title("1. Systolic BP Distribution: Bimodal Peaks at 128 mmHg and 160 mmHg", fontsize=11, fontweight="bold", loc="left", pad=10)
    ax1.set_xlabel("Systolic Blood Pressure (mmHg) [Bin Width ≈ 3.4 mmHg]", fontsize=10)
    ax1.set_ylabel("Patient Count", fontsize=10)
    ax1.legend(loc="upper right", fontsize=8, frameon=False)
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    
    # ----------------------------------------------------
    # Panel 2: Length of Stay across Wards (Box Plot on Long Data)
    # ----------------------------------------------------
    ax2 = axes[0, 1]
    ward_order = ['Day Surgery', 'General Medicine', 'Cardiology', 'ICU']
    palette_dict = {
        'Day Surgery': '#7570b3',
        'General Medicine': '#2b5c8f',
        'Cardiology': '#d95f02',
        'ICU': '#e7298a'
    }
    sns.boxplot(data=df_los, x='ward', y='los_days', order=ward_order, palette=palette_dict, ax=ax2, width=0.5, fliersize=2)
    ax2.set_title("2. ICU Admissions Require Longest Stay (Median 4.8 Days) vs Day Surgery (<1 Day)", fontsize=11, fontweight="bold", loc="left", pad=10)
    ax2.set_xlabel("Admitting Ward", fontsize=10)
    ax2.set_ylabel("Inpatient Length of Stay (days)", fontsize=10)
    ax2.set_ylim(-0.5, 15) # Clip visual scale for clarity while preserving box medians
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    
    # ----------------------------------------------------
    # Panel 3: Scatter Plot of Systolic vs Diastolic BP
    # ----------------------------------------------------
    ax3 = axes[1, 0]
    ax3.scatter(df_vitals['diastolic'], df_vitals['systolic'], alpha=0.15, color=primary_color, s=15, edgecolors="none")
    
    # Add OLS trendline
    slope, intercept = np.polyfit(df_vitals['diastolic'], df_vitals['systolic'], 1)
    x_vals = np.array([df_vitals['diastolic'].min(), df_vitals['diastolic'].max()])
    ax3.plot(x_vals, intercept + slope * x_vals, color=accent_color, linewidth=2.0, label=f"OLS Trendline (r = 0.889)")
    
    ax3.set_title("3. Strong Non-Arithmetic Physiological Correlation (r = 0.889)", fontsize=11, fontweight="bold", loc="left", pad=10)
    ax3.set_xlabel("Diastolic Blood Pressure (mmHg)", fontsize=10)
    ax3.set_ylabel("Systolic Blood Pressure (mmHg)", fontsize=10)
    ax3.text(0.05, 0.90, "Note: Excluded derived map_mmhg\n[MAP = (SBP + 2·DBP)/3 is arithmetic]", 
             transform=ax3.transAxes, fontsize=8, bbox=dict(boxstyle="round,pad=0.3", facecolor="#f8f9fa", edgecolor="#cccccc"))
    ax3.legend(loc="lower right", fontsize=8, frameon=False)
    ax3.spines['top'].set_visible(False)
    ax3.spines['right'].set_visible(False)
    
    # ----------------------------------------------------
    # Panel 4: Annotated Correlation Heatmap
    # ----------------------------------------------------
    ax4 = axes[1, 1]
    eval_cols = ['age', 'systolic', 'diastolic', 'heart_rate', 'spo2', 'bmi', 'chol_mmol_l', 'glucose_mmol_l', 'los_days']
    col_labels = ['Age', 'Systolic', 'Diastolic', 'Heart Rate', 'SpO2', 'BMI', 'Cholesterol', 'Glucose', 'LOS Days']
    corr_matrix = df_vitals[eval_cols].corr()
    
    sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm", vmin=-1.0, vmax=1.0, 
                xticklabels=col_labels, yticklabels=col_labels, ax=ax4, cbar_kws={'label': 'Pearson Correlation (r)'},
                annot_kws={"size": 7.5})
    ax4.set_title("4. Correlation Heatmap of Calibrated Vital Sign Measurements", fontsize=11, fontweight="bold", loc="left", pad=10)
    ax4.tick_params(axis='x', rotation=45)
    ax4.tick_params(axis='y', rotation=0)
    
    # Overall Title & Source Footnote
    fig.suptitle("Clinical Safety Review: Vital Sign Distribution, Ward Utilization, and Correlation Audit", 
                 fontsize=14, fontweight="bold", y=0.98, color="#111111")
    
    footnote_text = ("Data Source: Synthetic clinical trial vitals (N=10,000 records). "
                     "Cleaned N=29 HR device faults (>250 bpm) & N=402 BMI placeholders (999.0). "
                     "Derived MAP excluded from pairwise analysis.")
    fig.text(0.5, 0.01, footnote_text, ha="center", fontsize=8.5, color="#555555", style="italic")
    
    # Save figure BEFORE plt.show()
    fig.savefig(output_filename, dpi=300, bbox_inches="tight")
    print(f"Successfully saved high-resolution 300 DPI figure to {output_filename}")
    plt.close(fig)

def main():
    vitals_file = os.path.join(os.path.dirname(__file__), "Datasets", "vitals_10k.csv")
    los_file = os.path.join(os.path.dirname(__file__), "Datasets", "ward_los_wide.csv")
    
    df_vitals = clean_vitals_data(vitals_file)
    df_los = load_ward_los_data(los_file)
    
    build_clinical_review_figure(df_vitals, df_los, "partD_figure.png")

if __name__ == "__main__":
    main()
