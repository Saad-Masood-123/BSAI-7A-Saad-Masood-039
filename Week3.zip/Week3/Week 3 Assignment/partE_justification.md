# Part E · Written Justification: Clinical Review Figure
**Course:** Data Visualization Lab (CDB601220) — Week 3  
**Student Name / ID:** BSAI-7A-AbdulMoeez-017  
**Artifact Target:** `partD_figure.png` (2×2 Clinical Safety Review Figure)

---

## 1. Per-Panel Justification: Questions, Chart Types, and Visual Channels

| Panel | Core Clinical Question Answered | Selected Chart Type & Rationale | Enforced Visual Channel Rules (Week 2) |
|---|---|---|---|
| **1. Top-Left** | *What is the underlying distribution of patient systolic blood pressure upon admission, and do clinical risk subgroups exist?* | **Histogram + KDE Density Curve (`bins=35`).** Continuous 1D distributions are best visualized via binned position along an aligned axis, supported by non-parametric density estimation to reveal multi-modality without binning artifacts. | **2D Position along aligned linear scale** (highest accuracy ranking). Length of vertical bars encodes bin frequency. Color hue is kept mono-chromatic (`#2b5c8f`) to avoid double-encoding density. |
| **2. Top-Right** | *How does inpatient length of stay (LOS) vary across admitting hospital wards?* | **Horizontal/Vertical Box Plot (`sns.boxplot` on melted long data).** Categorical-to-continuous comparisons require summary statistics (median, IQR, whiskers) across groups rather than raw bar means. | **Position along aligned scale** for quartiles; **Spatial Separation** (grouping by ward category). Distinct color hues are assigned per ward with high perceptual contrast. |
| **3. Bottom-Left** | *What is the pairwise physiological relationship between systolic and diastolic blood pressure measurements?* | **Scatter Plot with OLS Regression Trendline (`alpha=0.15`).** Bivariate continuous relationships require scatter representations to assess linearity, slope, and variance. | **2D Position (x, y)** for individual patient coordinates. **Luminance/Alpha opacity** encodes local point density to solve overplotting of $N \approx 10,000$ points. |
| **4. Bottom-Right** | *Which calibrated vital sign indicators exhibit significant inter-variable correlation?* | **Annotated Correlation Heatmap (`fmt='.2f'`, `vmin=-1, vmax=1`).** Matrix relationships across $>5$ variables require grid alignment with explicit numerical callouts to prevent cognitive overload. | **Color Diverging Hue & Saturation** (`coolwarm` palette: red for positive correlation, blue for negative) mapped to a normalized linear scale $[-1, +1]$. |

---

## 2. Parameter Selection & Design Defense

1. **`bins=35` (Panel 1):** Sets an optimal bin width of $\approx 3.4\text{ mmHg}$ ($[199-60]/35$). This fine granularity clearly separates the normal physiological peak ($128\text{ mmHg}$) from the Stage 2 hypertensive sub-population peak ($160\text{ mmHg}$) without introduction of histogram noise.
2. **`kde=True` (Panel 1):** Overlays Gaussian kernel density estimation to provide a smooth, continuous estimate of underlying probability mass function.
3. **`pandas.melt()` (Panel 2):** Reshapes ragged wide data (`ward_los_wide.csv`) into tidy long format (`ward`, `los_days`). Passing wide matrices directly to Seaborn produces broken category axes or missing series errors.
4. **`showfliers=True`, `fliersize=2`, `ylim=(-0.5, 15)` (Panel 2):** Preserves true visual representation of prolonged ICU stays up to 15 days while maintaining readable box geometries for routine admissions.
5. **`alpha=0.15`, `s=15` (Panel 3):** Reduces visual density of $10,000$ overlapping scatter markers. High-density regions appear naturally darker, allowing instant visual identification of the main physiological cluster around $(78\text{ mmHg}, 128\text{ mmHg})$.
6. **`map_mmhg` Exclusion (Panel 3 & 4):** Mean Arterial Pressure ($MAP = \frac{SBP + 2 \cdot DBP}{3}$) is an exact linear arithmetic derivative of systolic and diastolic BP. Plotting $MAP$ vs $SBP$ yields a tautological $r=0.967$ correlation artifact (Slide 46). It is excluded in favor of genuine $SBP$ vs $DBP$ ($r=0.889$).
7. **`annot=True`, `fmt='.2f'`, `vmin=-1.0, vmax=1.0` (Panel 4):** Enforces explicit two-decimal numerical precision on correlation values, removing ambiguity while anchoring the visual color scale symmetrically around zero.
8. **`fig.savefig("partD_figure.png", dpi=300, bbox_inches="tight")`:** Exports publication-grade 300 DPI graphics before invoking `plt.show()`, preventing blank image exports.

---

## 3. Data Cleaning, Row Removal, and Ethics Clause

### Data Cleaning Summary Table

| Data Quality Issue | Diagnostic Identification | Applied Cleaning Rule & Method | Affected Count ($n$) | Pre-Cleaning Metric | Post-Cleaning Metric |
|---|---|---|---|---|---|
| **Heart Rate Faults** | `df.describe()` max = $415\text{ bpm}$ | Excluded non-physiological readings $> 250\text{ bpm}$ | $n = 29$ | Mean HR: $78.83\text{ bpm}$ | Mean HR: $77.98\text{ bpm}$ |
| **BMI Placeholder Code** | `df.describe()` max = $999.0\text{ kg/m}^2$ | Converted database sentinel code ($999.0$) to `NaN` | $n = 402$ | Mean BMI: $66.18\text{ kg/m}^2$ | Mean BMI: $27.11\text{ kg/m}^2$ |
| **Dirty Ward Labels** | 12 string variants in `df.ward` | Standardized to 4 canonical categories | $N = 10,000$ | 12 raw categories | 4 clean categories |
| **Mixed Date Formats** | Heterogeneous ISO, DD-MMM, DD/MM | Parsed using `pd.to_datetime(format='mixed')` | $N = 10,000$ | Unparsed strings | Unified Datetime64 |

---

### Ethics Clause (Mandatory Compliance Statement)

> **Readings above $250\text{ bpm}$ were removed as device faults ($n = 29$). Mean heart rate moves from $78.83$ to $77.98\text{ bpm}$. The figure was also produced without the exclusion; it is documented in the audit log.**
> 
> **Symmetry Test Verification:** We evaluated this cleaning rule against Week 2's symmetry principle: *Would we have made the exact same removal if it had weakened our clinical conclusion instead of strengthening it?* The answer is **yes**. A resting human heart rate exceeding $250\text{ bpm}$ (reaching up to $415\text{ bpm}$) is a physical impossibility caused by telemetry sensor disconnects or high-frequency electrical interference. This rule is grounded strictly in biological signal validity, independent of hypothesis direction.
