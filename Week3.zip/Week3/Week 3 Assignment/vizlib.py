"""
vizlib.py — Course Toolkit for Week 3: Matplotlib & Seaborn
Contains palette definitions, Lie Factor calculation, CVD simulation, and color difference tools.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Course Palette Definition
PALETTE = {
    "series": ["#2b5c8f", "#d95f02", "#7570b3", "#e7298a"],
    "primary": "#2b5c8f",
    "popout": "#e74c3c",
    "context": "#d0d0d0"
}

def lie_factor(data_start, data_end, ink_start, ink_end, ink_dimension=1):
    """
    Computes Tufte's Lie Factor:
        Lie Factor = (Graphic Effect) / (Data Effect)
    where Effect = (Final - Initial) / Initial.
    If ink_dimension == 2 and ink values represent linear lengths/radii,
    the graphic area effect is calculated from squared ink values.
    """
    data_effect = (data_end - data_start) / data_start
    
    if ink_dimension == 2:
        # Area effect computed from squared linear dimensions
        graphic_effect = (ink_end**2 - ink_start**2) / (ink_start**2)
    else:
        graphic_effect = (ink_end - ink_start) / ink_start
        
    lf = graphic_effect / data_effect
    return round(data_effect, 4), round(graphic_effect, 4), round(lf, 4)

def hex_to_rgb(hex_str):
    """Converts hex color string to normalized RGB float tuple (0.0 to 1.0)."""
    hex_str = hex_str.lstrip('#')
    return tuple(int(hex_str[i:i+2], 16) / 255.0 for i in (0, 2, 4))

def rgb_to_hex(rgb):
    """Converts normalized RGB tuple to hex color string."""
    return '#{:02x}{:02x}{:02x}'.format(int(round(rgb[0]*255)), int(round(rgb[1]*255)), int(round(rgb[2]*255)))

# Machado et al. (2009) CVD Transformation Matrices for Deuteranopia, Protanopia, Tritanopia
CVD_MATRICES = {
    "deutan": np.array([
        [0.43, 0.72, -0.15],
        [0.34, 0.57, 0.09],
        [-0.02, 0.03, 1.00]
    ]),
    "protan": np.array([
        [0.15, 0.99, -0.14],
        [0.11, 0.86, 0.03],
        [-0.01, 0.02, 1.00]
    ]),
    "tritan": np.array([
        [0.95, 0.05, 0.00],
        [0.00, 0.43, 0.57],
        [0.00, 0.47, 0.53]
    ])
}

def simulate_cvd(colors, cvd_type="deutan"):
    """
    Simulates Color Vision Deficiency (deutan, protan, or tritan) for a list of hex color strings.
    Returns a list of simulated hex color strings.
    """
    cvd_type = cvd_type.lower()
    if cvd_type not in CVD_MATRICES:
        raise ValueError(f"Unknown cvd_type: {cvd_type}. Choose from 'deutan', 'protan', 'tritan'.")
        
    matrix = CVD_MATRICES[cvd_type]
    simulated_hex = []
    
    for c in colors:
        rgb = np.array(hex_to_rgb(c))
        # Transform RGB by CVD matrix
        sim_rgb = np.dot(matrix, rgb)
        sim_rgb = np.clip(sim_rgb, 0.0, 1.0)
        simulated_hex.append(rgb_to_hex(sim_rgb))
        
    return simulated_hex

def delta_e(c1_hex, c2_hex):
    """Calculates Euclidean distance in RGB color space as an approximation of Delta E."""
    rgb1 = np.array(hex_to_rgb(c1_hex))
    rgb2 = np.array(hex_to_rgb(c2_hex))
    return np.linalg.norm(rgb1 - rgb2) * 100.0

def worst_pair(colors, cvd_type="deutan"):
    """
    Finds the pair of colors in the palette that collapses worst (minimum Delta E) under CVD simulation.
    Returns ((c1_idx, c2_idx), (c1_orig, c2_orig), (c1_sim, c2_sim), min_delta_e).
    """
    sim_colors = simulate_cvd(colors, cvd_type)
    min_dE = float('inf')
    best_pair_indices = (0, 1)
    
    for i in range(len(colors)):
        for j in range(i + 1, len(colors)):
            dE = delta_e(sim_colors[i], sim_colors[j])
            if dE < min_dE:
                min_dE = dE
                best_pair_indices = (i, j)
                
    i, j = best_pair_indices
    return {
        "indices": (i, j),
        "original_pair": (colors[i], colors[j]),
        "simulated_pair": (sim_colors[i], sim_colors[j]),
        "delta_e": round(min_dE, 2)
    }

def match_stats(df, x_col, y_col):
    """Returns summary stats dictionary for matching datasets."""
    return {
        "mean_x": round(df[x_col].mean(), 2),
        "mean_y": round(df[y_col].mean(), 2),
        "std_x": round(df[x_col].std(), 2),
        "std_y": round(df[y_col].std(), 2),
        "r": round(df[x_col].corr(df[y_col]), 3)
    }

if __name__ == "__main__":
    print("Self-check: vizlib toolkit loaded successfully.")
    de, ge, lf = lie_factor(25.0, 30.0, 5.0, 6.0, 1)
    print(f"Chart C Self-Check: Data Effect={de}, Graphic Effect={ge}, Lie Factor={lf}")
